"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Event_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Event"));
const Env_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Env"));
const desko_persistence_1 = __importDefault(require("./desko.persistence"));
const Database_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Lucid/Database"));
const desko_api_provider_1 = __importDefault(require("./api/desko.api.provider"));
const desko_api_service_1 = __importDefault(require("./api/desko.api.service"));
class DeskoCore {
    webhook(name, callback) {
        Event_1.default.on(`webhook:${name}`, (event) => callback(event));
    }
    service() {
        return new desko_api_service_1.default();
    }
    provider() {
        return new desko_api_provider_1.default();
    }
    persist() {
        return new desko_persistence_1.default();
    }
    schedule(callback) {
        callback();
        let minutes = Number.parseInt(Env_1.default.get('CONTROLID_SCHEDULE_POOLING_MINUTES'));
        if (!minutes || minutes < 1) {
            minutes = 5;
        }
        return require('node-schedule').scheduleJob(`*/${minutes} * * * *`, async () => callback());
    }
    database(storeConnection, connection) {
        if (!Database_1.default.manager.has(storeConnection)) {
            Database_1.default.manager.add(storeConnection, connection);
            Database_1.default.manager.connect(storeConnection);
        }
        return Database_1.default.connection(storeConnection);
    }
}
exports.default = DeskoCore;
//# sourceMappingURL=desko.core.js.map