"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=desko.booking.dto.js.map