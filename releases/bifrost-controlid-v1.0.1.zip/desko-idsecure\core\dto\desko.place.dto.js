"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=desko.place.dto.js.map