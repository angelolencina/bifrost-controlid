"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const luxon_1 = require("luxon");
const desko_core_1 = __importDefault(require("../core/desko.core"));
const Env_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Env"));
const Logger_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Logger"));
const axios = require('axios');
const https = require('https');
class Plugin extends desko_core_1.default {
    init() {
        if (!this.connIdSecureDb()) {
            return;
        }
        if (Env_1.default.get('CONTROLID_FUNCTION_ACCESS_CONTROL')) {
            this.schedule(() => this.sync());
            this.webhook('booking', async (deskoEvent) => {
                this.eventAccessControl(deskoEvent);
            });
        }
        if (Env_1.default.get('CONTROLID_FUNCTION_QRCODE')) {
            this.schedule(() => this.eventUserQrCode());
        }
    }
    connIdSecureDb() {
        const settings = this.configConnection();
        if (!settings) {
            Logger_1.default.warn(`connIdSecureDb: DB invalid data`);
            return false;
        }
        this.idSecureDb = this.database('controlIdMySQLConnection', {
            client: 'mysql',
            connection: settings,
        });
        return true;
    }
    async eventUserQrCode() {
        const query = `SELECT id, email FROM controlid.users where deleted = 0 AND id NOT IN (SELECT idUser FROM controlid.cards where idType = 1 AND type = 2)`;
        const response = await this.idSecureDb.rawQuery(query);
        const users = response[0] || null;
        if (!users || !users.length) {
            Logger_1.default.info(`eventUserQrCode : nenhum usuario`);
            return;
        }
        const accessToken = await this.authApi();
        const payload = [];
        for (const user of users) {
            const code = await this.createQrCode(accessToken, user.id);
            if (!code) {
                Logger_1.default.debug(`event: user:${user.id} code not found}`);
                continue;
            }
            await this.userSaveQrCode(user.id, code);
            payload.push({
                identifier_type: 'email',
                identifier: user.email,
                code: code
            });
            this.syncUser(accessToken, user.id);
        }
        this.service().api('POST', 'integrations/personal-badge', payload);
    }
    async eventAccessControl(deskoEvent) {
        Logger_1.default.debug(`event: eventAccessControl ${JSON.stringify(deskoEvent)}`);
        const event = await this.provider().runEvent(deskoEvent);
        if (!event) {
            Logger_1.default.error('Event NotFound');
        }
        if (event.action === 'deleted') {
            this.declinedAccess(event);
            return;
        }
        this.saveCache(event);
    }
    saveCache(event) {
        this.persist()
            .booking()
            .save({
            uuid: event.uuid,
            start_date: event.start_date,
            end_date: event.end_date,
            state: event.state,
            action: event.action,
            person: JSON.stringify(event.person),
            place: JSON.stringify(event.place),
            floor: JSON.stringify(event.floor),
            building: JSON.stringify(event.building),
        });
        if (!this.isToday(event)) {
            return;
        }
        this.persist().booking().setSync(event.uuid);
        this.userAccessLimit({
            email: event.person.email,
            start_date: event.start_date,
            end_date: event.end_date,
        });
        this.syncAll();
    }
    declinedAccess(event) {
        this.persist().booking().delete(event.uuid);
        if (!this.isToday(event)) {
            return;
        }
        this.userAccessLimit({
            email: event.person.email,
            start_date: new Date(2021, 0, 1, 0, 0, 0),
            end_date: new Date(2021, 0, 1, 0, 0, 0),
        });
        this.syncAll();
    }
    async sync() {
        const now = luxon_1.DateTime.local().toFormat('yyyy-MM-dd HH:mm:s');
        const dateStart = luxon_1.DateTime.local().startOf('day');
        const dateEnd = luxon_1.DateTime.local().endOf('day');
        const bookings = await this.persist()
            .booking()
            .query()
            .where('start_date', '>=', dateStart.toFormat('yyyy-MM-dd HH:mm:s'))
            .where('end_date', '<=', dateEnd.toFormat('yyyy-MM-dd HH:mm:s'))
            .whereNull('sync_date')
            .select('*');
        Logger_1.default.debug(`sync ${now}: ${bookings.length} bookings`);
        if (!bookings.length) {
            return;
        }
        bookings.map(async (booking) => {
            this.persist().booking().setSync(booking.uuid);
            this.userAccessLimit({
                email: booking.person.email,
                start_date: booking.start_date,
                end_date: booking.end_date,
            });
        });
        this.syncAll();
    }
    async getUser(email) {
        const user = await this.idSecureDb
            .query()
            .from('users')
            .where('email', email)
            .where('deleted', 0)
            .first();
        if (!user) {
            Logger_1.default.info(`userAccessLimit : ${email} not found`);
            return false;
        }
        return user;
    }
    async userSaveQrCode(userId, number) {
        Logger_1.default.debug(`userSaveQrCode : ${userId} : ${number}`);
        const query = `
      INSERT INTO cards (
        idUser, idType, type, number, numberStr
      ) VALUES (
        '${userId}', '1', '2', '${number}',
        (select CONCAT(CONVERT((${number} DIV 65536), CHAR), ",", CONVERT((${number} MOD 65536), CHAR)))
      )
    `;
        await this.idSecureDb.rawQuery(query);
    }
    async userAccessLimit({ email, start_date, end_date }) {
        Logger_1.default.debug(`userAccessLimit : ${email} : ${start_date}:${end_date}`);
        const user = await this.getUser(email);
        if (!user) {
            return;
        }
        await this.idSecureDb
            .query()
            .from('users')
            .where('id', user.id)
            .update({
            dateStartLimit: luxon_1.DateTime.fromJSDate(start_date).startOf('day').toFormat('yyyy-MM-dd HH:mm:ss'),
            dateLimit: luxon_1.DateTime.fromJSDate(end_date).endOf('day').toFormat('yyyy-MM-dd HH:mm:ss'),
        });
    }
    isToday(event) {
        return luxon_1.DateTime.fromJSDate(event.start_date).ordinal == luxon_1.DateTime.now().ordinal;
    }
    configConnection() {
        if (!Env_1.default.get('CONTROLID_MYSQL_USER') || !Env_1.default.get('CONTROLID_MYSQL_PASSWORD')) {
            return false;
        }
        return {
            host: Env_1.default.get('CONTROLID_MYSQL_HOST'),
            port: Env_1.default.get('CONTROLID_MYSQL_PORT'),
            user: Env_1.default.get('CONTROLID_MYSQL_USER'),
            password: Env_1.default.get('CONTROLID_MYSQL_PASSWORD'),
            database: Env_1.default.get('CONTROLID_MYSQL_DB_NAME'),
        };
    }
    async syncAll() {
        const url = `${Env_1.default.get('CONTROLID_API')}/util/SyncAll`;
        Logger_1.default.debug(`syncAll: ${url}`);
        try {
            const result = await axios({
                httpsAgent: new https.Agent({
                    rejectUnauthorized: false,
                }),
                method: 'GET',
                url: url,
            });
            Logger_1.default.debug(`syncAll Result : ${result.statusText} (${result.status})`);
        }
        catch (e) {
            Logger_1.default.error(`syncAll Error  : ${JSON.stringify(e)}`);
        }
    }
    async createQrCode(accessToken, userId) {
        const url = `${Env_1.default.get('CONTROLID_API')}/qrcode/userqrcode`;
        Logger_1.default.debug(`createUserQrCode: ${url}`);
        try {
            const result = await axios({
                httpsAgent: new https.Agent({
                    rejectUnauthorized: false,
                }),
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`,
                },
                method: 'POST',
                url: url,
                data: userId
            });
            return result.data || null;
        }
        catch (e) {
            Logger_1.default.error(`createUserQrCode Error  : ${JSON.stringify(e)}`);
        }
    }
    async syncUser(accessToken, userId) {
        const url = `${Env_1.default.get('CONTROLID_API')}/util/SyncUser/${userId}`;
        Logger_1.default.debug(`syncUser: ${url}`);
        try {
            const result = await axios({
                httpsAgent: new https.Agent({
                    rejectUnauthorized: false,
                }),
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                },
                method: 'GET',
                url: url
            });
            Logger_1.default.debug(`Result : ${result.statusText} (${result.status})`);
            Logger_1.default.debug(`Payload: ${JSON.stringify(result.data)}`);
        }
        catch (e) {
            Logger_1.default.error(`createUserQrCode Error  : ${JSON.stringify(e)}`);
        }
    }
    async authApi() {
        const url = `${Env_1.default.get('CONTROLID_API')}/login`;
        Logger_1.default.debug(`Login: ${url}`);
        try {
            const result = await axios({
                httpsAgent: new https.Agent({
                    rejectUnauthorized: false,
                }),
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': 'application/json',
                },
                data: {
                    username: Env_1.default.get('CONTROLID_API_USER'),
                    password: Env_1.default.get('CONTROLID_API_PASSWORD')
                }
            });
            Logger_1.default.debug(`Result : ${result.statusText} (${result.status})`);
            Logger_1.default.debug(`Payload: ${JSON.stringify(result.data)}`);
            return result.data.accessToken || null;
        }
        catch (e) {
            Logger_1.default.debug(`Error  : ${e.message} (${e.response}))`);
        }
    }
}
exports.default = Plugin;
//# sourceMappingURL=index.js.map